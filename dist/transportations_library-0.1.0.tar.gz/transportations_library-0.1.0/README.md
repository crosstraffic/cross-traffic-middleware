## About

Middleware for transportation library and software applications.

Currently, it supports the connection between the Transportation Library and Cross Traffic Platform / Cross Traffic Web Calculator through WebAssembly.
Please import to Cargo from crates.io (https://lib.rs/crates/crosstraffic_middleware).
