## Setup Systems

We use:
- Autoware
- Nvidia GPU
- Docker
- Rocker



### References

- https://tier4.github.io/scenario_simulator_v2-docs/user_guide/RunWithDocker/