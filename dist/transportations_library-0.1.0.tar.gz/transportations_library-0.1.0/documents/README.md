## HCM-middleware

Generating scenario for HCM and the vehicle control system.

## Configuration

We are using scenario_simulator of Autoware (https://github.com/tier4/scenario_simulator_v2). Parameters of user's input corresponds to yaml parameters in the Autoware.

This can automatically generate testing scenario and run the docker under the hood. User can observe and interact through RVIZ.